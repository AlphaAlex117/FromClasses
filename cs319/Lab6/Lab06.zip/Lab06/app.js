//Imports
const express = require('express');

// express app
const app = express();

// listen for requests
app.listen(3000);

// register view engine
app.set('view engine', 'ejs');
// app.set('views', 'myviews');

//Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }))

//Temporary data
var donations = [
    {id:'code-' + Math.floor(Math.random() * 100000), name: 'John Smith', email: 'john.smith@iastate.edu',amount:100.00},
    {id:'code-' + Math.floor(Math.random() * 100000), name: 'John Doe', email: 'john.doe@iastate.edu',amount:75.00},
    {id:'code-' + Math.floor(Math.random() * 100000), name: 'Jane Doe', email: 'jane.doe@iastate.edu',amount:200.00},
  ];
