//Imports
const { json } = require('express');
const express = require('express');
const mongoose = require('mongoose')
const Donation = require('./models/donation')

// express app
const app = express();



// register view engine
app.set('view engine', 'ejs');
// app.set('views', 'myviews');

//Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }))
app.use(express.json())

//EDIT CONNECTION STRING
const dbURI = ''

mongoose.connect(dbURI).then((result) => {
  console.log("connected to db..")
  // listen for requests
  app.listen(3000);
}).catch((err) => console.log(err))

//Routing
app.get('/', (req, res) => {
  res.redirect('/donations')
});

app.get('/donations/', (req, res) => {
//ADD SNIPPET HERE
});

app.get('/about', (req, res) => {
  res.render('./about', { title: 'About' });
});

app.get('/donations/create', (req, res) => {
  res.render('./donations/create', { title: 'Donations' });
});

app.post('/donations', (req,res) => {
    //ADD SNIPPET HERE
})

app.post('/add_donation', (req,res) => {

  //ADD SNIPPET HERE
  
})

app.delete('/donations/:id', (req, res) => {
  //ADD SNIPPET HERE

});

app.get('/donations/:did', (req, res) => {
  //ADD SNIPPET HERE
});

// 404 page
app.use((req, res) => {
  res.status(404).render('404', { title: '404' });
});